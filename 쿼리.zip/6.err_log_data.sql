insert into err_log values(831,1, 400, 401);
insert into err_log values(831,3, 400, 401);
insert into err_log values(831,5, 400, 401);
insert into err_log values(831,6, 400, 401);
insert into err_log values(831,7, 400, 401);
insert into err_log values(831,13, 400, 401);
insert into err_log values(831,14, 400, 401);
insert into err_log values(831,15, 400, 401);
insert into err_log values(831,16, 400, 401);
insert into err_log values(831,21, 400, 401);
insert into err_log values(831,24, 400, 401);

insert into err_log values(355,4, 400, 402);
insert into err_log values(355,8, 400, 402);
insert into err_log values(355,11, 400, 402);
insert into err_log values(355,13, 400, 402);
insert into err_log values(355,15, 400, 402);
insert into err_log values(355,16, 400, 402);
insert into err_log values(355,17, 400, 402);
insert into err_log values(355,18, 400, 402);
insert into err_log values(355,19, 400, 402);
insert into err_log values(355,23, 400, 402);

insert into err_log values(922,3, 400, 402);
insert into err_log values(922,5, 400, 402);
insert into err_log values(922,6, 400, 402);
insert into err_log values(922,11, 400, 402);
insert into err_log values(922,12, 400, 402);
insert into err_log values(922,14, 400, 402);
insert into err_log values(922,22, 400, 402);
insert into err_log values(922,25, 400, 402);

insert into err_log values(123,1, 300, 303);
insert into err_log values(123,3, 300, 303);
insert into err_log values(123,12, 300, 303);
insert into err_log values(123,24, 300, 303);
insert into err_log values(123,25, 300, 303);

insert into err_log values(133, 7, 100, 102);
insert into err_log values(133, 12, 100, 102);
insert into err_log values(133, 16, 100, 102);

insert into err_log values(236,2, 300, 301);
insert into err_log values(236,5, 300, 301);
insert into err_log values(236,6, 300, 301);
insert into err_log values(236,7, 300, 301);
insert into err_log values(236,8, 300, 301);
insert into err_log values(236,9, 300, 301);
insert into err_log values(236,11, 300, 301);
insert into err_log values(236,15, 300, 301);
insert into err_log values(236,17, 300, 301);
insert into err_log values(236,19, 300, 301);
insert into err_log values(236,20, 300, 301);
insert into err_log values(236,21, 300, 301);
insert into err_log values(236,23, 300, 301);
insert into err_log values(236,24, 300, 301);

insert into err_log values(475,1, 400, 402);
insert into err_log values(475,3, 400, 402);
insert into err_log values(475,5, 400, 402);
insert into err_log values(475,10, 400, 402);
insert into err_log values(475,14, 400, 402);
insert into err_log values(475,15, 400, 402);
insert into err_log values(475,17, 400, 402);
insert into err_log values(475,20, 400, 402);
insert into err_log values(475,22, 400, 402);
insert into err_log values(475,25, 400, 402);

insert into err_log values(449,1, 400, 402);
insert into err_log values(449,4, 400, 402);
insert into err_log values(449,8, 400, 402);
insert into err_log values(449,11, 400, 402);
insert into err_log values(449,14, 400, 402);
insert into err_log values(449,16, 400, 402);
insert into err_log values(449,17, 400, 402);
insert into err_log values(449,18, 400, 402);
insert into err_log values(449,19, 400, 402);
insert into err_log values(449,20, 400, 402);
insert into err_log values(449,21, 400, 402);
insert into err_log values(449,22, 400, 402);

insert into err_log values(671,2, 200, 202);
insert into err_log values(671,3, 200, 202);
insert into err_log values(671,7, 200, 202);
insert into err_log values(671,8, 200, 202);

insert into err_log values(693,25, 200, 201);
insert into err_log values(693,22, 200, 201);
insert into err_log values(693,14, 200, 201);


insert into err_log values(699,1, 400, 405);
insert into err_log values(699,2, 400, 405);
insert into err_log values(699,3, 400, 405);
insert into err_log values(699,5, 400, 405);
insert into err_log values(699,7, 400, 405);
insert into err_log values(699,9, 400, 405);
insert into err_log values(699,10, 400, 405);
insert into err_log values(699,11, 400, 405);
insert into err_log values(699,14, 400, 405);
insert into err_log values(699,16, 400, 405);
insert into err_log values(699,20, 400, 405);
insert into err_log values(699,21, 400, 405);
insert into err_log values(699,23, 400, 405);
insert into err_log values(699,24, 400, 405);
insert into err_log values(699,25, 400, 405);

insert into err_log values(766,2, 400, 401);
insert into err_log values(766,9, 400, 401);
insert into err_log values(766,10, 400, 401);
insert into err_log values(766,11, 400, 401);
insert into err_log values(766,12, 400, 401);
insert into err_log values(766,13, 400, 401);
insert into err_log values(766,16, 400, 401);
insert into err_log values(766,17, 400, 401);
insert into err_log values(766,23, 400, 401);
insert into err_log values(766,25, 400, 401);





insert into err_log values(925,4, 400, 401);
insert into err_log values(925,5, 400, 401);
insert into err_log values(925,6, 400, 401);
insert into err_log values(925,7, 400, 401);
insert into err_log values(925,9, 400, 401);
insert into err_log values(925,10, 400, 401);
insert into err_log values(925,12, 400, 401);
insert into err_log values(925,17, 400, 402);
insert into err_log values(925,20, 400, 402);
insert into err_log values(925,21, 400, 402);
insert into err_log values(925,23, 400, 402);
insert into err_log values(925,24, 400, 402);


insert into err_log values(901,2, 300, 301);
insert into err_log values(901,3, 300, 301);
insert into err_log values(901,4, 300, 301);
insert into err_log values(901,5, 300, 301);
insert into err_log values(901,6, 300, 301);
insert into err_log values(901,7, 300, 301);
insert into err_log values(901,8, 300, 301);
insert into err_log values(901,9, 300, 301);
insert into err_log values(901,10, 300, 301);
insert into err_log values(901,11, 300, 301);
insert into err_log values(901,14, 300, 301);
insert into err_log values(901,15, 300, 301);
insert into err_log values(901,16, 300, 301);
insert into err_log values(901,17, 300, 301);
insert into err_log values(901,21, 300, 301);
insert into err_log values(901,22, 300, 301);
insert into err_log values(901,25, 300, 301);


insert into err_log values(461,1, 400 ,403);
insert into err_log values(461,2, 400 ,403);
insert into err_log values(461,4, 400 ,403);
insert into err_log values(461,5, 400 ,403);
insert into err_log values(461,10, 400 ,403);
insert into err_log values(461,11, 400 ,403);
insert into err_log values(461,13, 400 ,403);
insert into err_log values(461,16, 400 ,403);
insert into err_log values(461,18, 400 ,403);
insert into err_log values(461,20, 400 ,403);
insert into err_log values(461,22, 400 ,403);


insert into err_log values(485,2, 400, 401);
insert into err_log values(485,5, 400, 401);
insert into err_log values(485,7, 400, 401);
insert into err_log values(485,11, 400, 401);
insert into err_log values(485,14, 400, 401);
insert into err_log values(485,15, 400, 401);
insert into err_log values(485,18, 400, 401);
insert into err_log values(485,19, 400, 401);
insert into err_log values(485,20, 400, 401);
insert into err_log values(485,21, 400, 401);
insert into err_log values(485,22, 400, 401);
insert into err_log values(485,23, 400, 401);
insert into err_log values(485,24, 400, 401);
insert into err_log values(485,25, 400, 401);

insert into err_log values(365,5, 200, 201);
insert into err_log values(365,9, 200, 201);
insert into err_log values(365,11, 200, 201);
insert into err_log values(365,17, 200, 201);
insert into err_log values(365,20, 200, 201);
insert into err_log values(365,22, 200, 201);



insert into err_log values(349,8, 100, 101);
insert into err_log values(349,12, 100, 101);
insert into err_log values(349,16, 100, 101);
insert into err_log values(349,21, 100, 101);
insert into err_log values(349,23, 100, 101);
insert into err_log values(349,24, 100, 101);

insert into err_log values(702,1, 400, 401);
insert into err_log values(702,4, 400, 401);
insert into err_log values(702,5, 400, 401);
insert into err_log values(702,6, 400, 401);
insert into err_log values(702,7, 400, 401);
insert into err_log values(702,11, 400, 401);
insert into err_log values(702,12, 400, 401);
insert into err_log values(702,13, 400, 401);
insert into err_log values(702,15, 400, 401);
insert into err_log values(702,20, 400, 401);
insert into err_log values(702,21, 400, 401);

insert into err_log values(149,1, 300, 301);
insert into err_log values(149,5, 300, 301);
insert into err_log values(149,6, 300, 301);
insert into err_log values(149,9, 300, 301);
insert into err_log values(149,10, 300, 302);
insert into err_log values(149,14, 300, 302);
insert into err_log values(149,15, 300, 302);
insert into err_log values(149,19, 300, 302);
insert into err_log values(149,20, 300, 302);
insert into err_log values(149,21, 300, 302);
insert into err_log values(149,23, 300, 303);
insert into err_log values(149,25, 300, 303);

insert into err_log values(221,4, 400, 401);
insert into err_log values(221,7, 400, 401);
insert into err_log values(221,11, 400, 401);
insert into err_log values(221,12, 400, 401);
insert into err_log values(221,14, 400, 401);
insert into err_log values(221,18, 400, 401);
insert into err_log values(221,19, 400, 401);
insert into err_log values(221,21, 400, 401);
insert into err_log values(221,24, 400, 401);

insert into err_log values(108,1, 400, 404);
insert into err_log values(108,3, 400, 404);
insert into err_log values(108,7, 400, 404);
insert into err_log values(108,10, 400, 404);
insert into err_log values(108,14, 400, 404);
insert into err_log values(108,16, 400, 403);
insert into err_log values(108,18, 400, 403);
insert into err_log values(108,22, 400, 403);
